﻿param([switch]$SelfTest,[ValidateRange(0,10)][int]$ResumeNumber=0,[switch]$ResumeToEnd)
Add-Type -AssemblyName System.Windows.Forms,UIAutomationClient,UIAutomationTypes
. (Join-Path $PSScriptRoot 'app-update.ps1')
$script:legacyType='System.Windows.Automation.LegacyIAccessiblePattern' -as [type]
Add-Type -AssemblyName Accessibility
Add-Type -ReferencedAssemblies Accessibility -TypeDefinition @'
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Accessibility;
public static class RoutineAccessible {
 [DllImport("oleacc.dll")] static extern int AccessibleObjectFromWindow(IntPtr window, uint objectId, ref Guid iid, [MarshalAs(UnmanagedType.Interface)] out object result);
 [DllImport("oleacc.dll")] static extern int AccessibleChildren(IAccessible container, int start, int count, [Out, MarshalAs(UnmanagedType.LPArray, SizeParamIndex=2)] object[] children, out int obtained);
 public sealed class Item {
  public bool IsMsaa { get { return true; } }
  public IAccessible Accessible; public object Child;
  public string Name { get { try { return Accessible.get_accName(Child) ?? ""; } catch { return ""; } } }
  public int Role { get { try { return Convert.ToInt32(Accessible.get_accRole(Child)); } catch { return 0; } } }
  public int State { get { return Convert.ToInt32(Accessible.get_accState(Child)); } }
  public string BoundsKey { get { try { int x,y,w,h; Accessible.accLocation(out x,out y,out w,out h,Child); return x+","+y+","+w+","+h; } catch { return "unknown"; } } }
  public bool Visible { get { try { int x,y,w,h; Accessible.accLocation(out x,out y,out w,out h,Child); return (State & 98304)==0 && w>0 && h>0; } catch { return false; } } }
  public void Click() { Accessible.accDoDefaultAction(Child); }
 }
 static void Walk(IAccessible acc, List<Item> result, int depth) {
  if(depth > 30 || result.Count > 2000) return;
  result.Add(new Item { Accessible=acc, Child=0 });
  int count; try { count=acc.accChildCount; } catch { return; }
  if(count <= 0 || count > 2000) return;
  var children=new object[count]; int obtained;
  if(AccessibleChildren(acc,0,count,children,out obtained) < 0) return;
  for(int i=0;i<obtained;i++) {
   var nested=children[i] as IAccessible;
   if(nested != null) Walk(nested,result,depth+1);
   else if(children[i] is int) result.Add(new Item { Accessible=acc, Child=children[i] });
  }
 }
 public static Item[] List(IntPtr window) {
  var result=new List<Item>(); object value;
  Guid iid=new Guid("618736E0-3C3D-11CF-810C-00AA00389B71");
  if(AccessibleObjectFromWindow(window,0xFFFFFFFC,ref iid,out value) >= 0) {
   var root=value as IAccessible; if(root!=null) Walk(root,result,0);
  }
  return result.ToArray();
 }
}
'@
Add-Type -TypeDefinition @'
using System;
using System.Text;
using System.Collections.Generic;
using System.Runtime.InteropServices;
public static class RoutineWindowFinder {
 public delegate bool EnumProc(IntPtr handle, IntPtr data);
 [DllImport("user32.dll")] static extern bool EnumWindows(EnumProc callback, IntPtr data);
 [DllImport("user32.dll", CharSet=CharSet.Unicode)] static extern int GetWindowText(IntPtr handle, StringBuilder text, int count);
 [DllImport("user32.dll", CharSet=CharSet.Unicode)] static extern int GetClassName(IntPtr handle, StringBuilder text, int count);
 [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr handle, out uint process);
 [DllImport("user32.dll")] static extern bool IsWindowVisible(IntPtr handle);
 public sealed class Entry { public IntPtr Handle; public string Title; public string ClassName; }
 public static Entry[] List(int process) {
  var entries = new List<Entry>();
  EnumWindows(delegate(IntPtr handle, IntPtr data) {
   uint actual; GetWindowThreadProcessId(handle, out actual);
   if(actual == process && IsWindowVisible(handle)) {
    var text=new StringBuilder(1024); GetWindowText(handle,text,text.Capacity);
    var className=new StringBuilder(256);GetClassName(handle,className,className.Capacity);
    entries.Add(new Entry { Handle=handle, Title=text.ToString(),ClassName=className.ToString() });
   }
   return true;
  },IntPtr.Zero);
  return entries.ToArray();
 }
}
'@
$ErrorActionPreference='Stop'
$base=Split-Path $PSScriptRoot -Parent
$settingsFile=Join-Path $PSScriptRoot 'settings.json'
if(Test-Path -LiteralPath $settingsFile){
 try{$savedSettings=Get-Content -LiteralPath $settingsFile -Raw | ConvertFrom-Json;if(Test-Path -LiteralPath $savedSettings.ExcelFolder -PathType Container){$base=$savedSettings.ExcelFolder}}catch{}
}
function CheckRange($first,$last){if($first -gt $last){throw '끝 번호는 시작 번호보다 크거나 같아야 합니다.'}}
$script:book=$null; $script:excel=$null; $script:waiting=$false; $script:stopped=$false
$accountFile=Join-Path $PSScriptRoot 'accounts.xml'
$finishRequest=Join-Path $PSScriptRoot 'finish-request.txt'
function LoadAccounts {
 $result=@{}
 if(Test-Path -LiteralPath $accountFile){
  foreach($account in (Import-Clixml -LiteralPath $accountFile)){$result[[int]$account.Number]=$account}
 }
 return $result
}
function AccountSettings {
 $stored=LoadAccounts
 $settings=New-Object Windows.Forms.Form
 $settings.Text='1~10번 계정 설정';$settings.Size=New-Object Drawing.Size(670,530);$settings.StartPosition='CenterParent'
 $note=New-Object Windows.Forms.Label;$note.Text="비밀번호는 그대로 표시하며 현재 Windows 사용자 계정으로 암호화해 저장합니다.`r`n번호별 아이디와 비밀번호를 확인한 뒤 저장하세요. 빈 비밀번호는 기존 값을 유지합니다.";$note.SetBounds(15,15,620,45);$settings.Controls.Add($note)
 $grid=New-Object Windows.Forms.DataGridView;$grid.SetBounds(15,70,620,340);$grid.AllowUserToAddRows=$false;$grid.AllowUserToDeleteRows=$false;$grid.RowHeadersVisible=$false;$grid.AutoSizeColumnsMode='Fill'
 [void]$grid.Columns.Add('Number','번호');[void]$grid.Columns.Add('Username','아이디');[void]$grid.Columns.Add('Password','비밀번호');$grid.Columns[0].ReadOnly=$true;$grid.Columns[0].FillWeight=35
 for($i=1;$i -le 10;$i++){
  $username=$users[$i-1];$password=''
  if($stored.ContainsKey($i)){
   $username=$stored[$i].Username
   $savedCredential=New-Object Management.Automation.PSCredential($username,$stored[$i].Password)
   $password=$savedCredential.GetNetworkCredential().Password
  }
  [void]$grid.Rows.Add([object[]]@($i,$username,$password))
  $password=$null;$savedCredential=$null
 }
 $settings.Controls.Add($grid)
 $saveAccounts=New-Object Windows.Forms.Button;$saveAccounts.Text='계정 정보 저장';$saveAccounts.SetBounds(450,425,185,35);$settings.Controls.Add($saveAccounts)
 $saveAccounts.Add_Click({
  try{
   [void]$grid.EndEdit();$newAccounts=@()
   foreach($row in $grid.Rows){
    $id=[int]$row.Cells[0].Value;$username=([string]$row.Cells[1].Value).Trim();$password=[string]$row.Cells[2].Value
    if(!$username -or $username -match '[,\r\n]'){throw "$id 번 아이디를 확인하세요."}
    if($password){
     if($password -match '[,\r\n]'){throw "$id 번 비밀번호에 지원하지 않는 구분 문자가 있습니다."}
     $secure=ConvertTo-SecureString $password -AsPlainText -Force
    }elseif($stored.ContainsKey($id)){$secure=$stored[$id].Password}else{throw "$id 번 비밀번호를 입력하세요."}
    $newAccounts += [pscustomobject]@{Number=$id;Username=$username;Password=$secure}
   }
   $newAccounts | Export-Clixml -LiteralPath $accountFile
   foreach($row in $grid.Rows){$row.Cells[2].Value=''}
   Log '1~10번 계정 정보를 암호화 저장했습니다.';$settings.Close()
  }catch{[void][Windows.Forms.MessageBox]::Show($_.Exception.Message,'계정 설정')}
 })
 [void]$settings.ShowDialog($form);$settings.Dispose()
}
$users=@('','','','','','','','','','')
$keywords=@('집밥 식단','육아템','주말 근교 여행','동탄키즈카페','동탄 아이랑 갈만한곳','수원 실내 놀이터','용인 아이랑 나들이','분당 키즈카페','일산 아이랑 실내','김포 대형 키즈카페','파주 아이랑 나들이','하남 아이랑 갈만한곳','남양주 주말 나들이','다산 아이랑 카페','광교 브런치 카페','동탄 브런치 카페','분당 주차 편한 카페','수원 아기랑 카페','일산 테라스 카페','용인 한옥 카페','김포 브런치 맛집','하남 유모차 카페','파주 정원 카페','양평 아이랑 카페','남양주 강변 카페','직장인 일주일 도시락','전자레인지 도시락 반찬','초등학생 아침밥 메뉴','유아 간식 만들기','퇴근 후 간단한 저녁','2인 집밥 식단','아이랑 먹는 주말 점심','냉동실 정리 집밥','에어프라이어 고구마 굽기','두부 계란 반찬','냉장고 야채칸 정리','좁은 주방 수납','싱크대 하부장 정리','욕실 물때 청소','아이 옷 수납','겨울 이불 보관','어린이집 등원 준비물','초등 입학 준비물','유모차 정리함 후기','휴대용 아기 의자 후기','아기 간식 용기 후기','건성 피부 수분크림 후기','새치 셀프 염색 후기','퇴근 후 어깨 스트레칭','초보 필라테스 후기','주말 도자기 원데이클래스','동탄 원데이클래스','분당 꽃꽂이 클래스','서울 근교 당일치기 가족여행','경기도 비오는날 아이랑','가평 아이랑 숙소')
function Log($s){
 $line="$(Get-Date -Format HH:mm:ss)  $s"
 $log.AppendText($line+"`r`n")
 Add-Content -LiteralPath (Join-Path $PSScriptRoot 'routine.log') -Value $line -Encoding UTF8
 [Windows.Forms.Application]::DoEvents()
}
function ReportFailure($errorRecord){
 Log ('작업 중단: '+$errorRecord.Exception.Message)
 $idleLabel.Text='오류 내용은 아래 기록 확인 (확인창 없음)'
}
function Nodes($root){ @($root.FindAll([System.Windows.Automation.TreeScope]::Descendants,[System.Windows.Automation.Condition]::TrueCondition)) }
function ExcelWindows {
 $root=[System.Windows.Automation.AutomationElement]::RootElement
 @($root.FindAll([System.Windows.Automation.TreeScope]::Children,[System.Windows.Automation.Condition]::TrueCondition) | Where-Object {$_.Current.ProcessId -eq $script:pidExcel})
}
function WaitWindow($title){
 $until=(Get-Date).AddSeconds(45)
 $normalized=$title -replace '\s',''
 do {
  if($script:stopped){throw '중지됨'}
  $native=@([RoutineWindowFinder]::List($script:pidExcel))
  $found=@($native | Where-Object {
   $name=$_.Title -replace '\s',''
   if($normalized -like '*불러오기*'){$name -like '*아이디*불러오기*'}else{$name -eq $normalized}
  })
  if($found.Count -eq 1){return [System.Windows.Automation.AutomationElement]::FromHandle($found[0].Handle)}
  $wins=@(ExcelWindows | Where-Object {($_.Current.Name -replace '\s','') -like "*$normalized*"})
  if($wins.Count -eq 1){return $wins[0]}
  [Windows.Forms.Application]::DoEvents();Start-Sleep -Milliseconds 250
 }while((Get-Date) -lt $until)
 $titles=($native | ForEach-Object {$_.Title}) -join ' / '
 Log "감지된 엑셀 창: $titles"
 throw "창을 찾을 수 없습니다: $title. 엑셀에서 확인 후 다시 시작하세요."
}
function ControlLabel($text){
 (([string]$text -replace '[\s&\u200B\uFEFF]','') -replace '^\d+[.．、:：)\-]*','').Trim()
}
function Named($root,$name){
 $elements=@(Nodes $root)
 $label=ControlLabel $name
 $found=@($elements | Where-Object {(ControlLabel $_.Current.Name) -eq $label})
 if($found.Count -gt 1){
  $interactive=@($found | Where-Object {$_.Current.ControlType -in @([System.Windows.Automation.ControlType]::CheckBox,[System.Windows.Automation.ControlType]::Button)})
  if($interactive.Count -eq 1){$found=$interactive}
 }
 if($found.Count -eq 0 -and $name -match '^([123])\.'){
  $ordinal=[int]$Matches[1]
  $boxes=@($elements | Where-Object {$_.Current.ControlType -eq [System.Windows.Automation.ControlType]::CheckBox} | Sort-Object {$_.Current.BoundingRectangle.Top})
  # Use order only for the known three-checkbox extraction form.
  if($boxes.Count -eq 3 -and (ControlLabel $root.Current.Name) -like '*아이디불러오기*'){
   $found=@($boxes[$ordinal-1])
   Log "$ordinal 번 체크박스를 화면 순서로 확인했습니다."
  }
 }
 if($found.Count -eq 0){
  $accessible=@([RoutineAccessible]::List([IntPtr]$root.Current.NativeWindowHandle))
  $matchesAccessible=@($accessible | Where-Object {(ControlLabel $_.Name) -eq $label -and $_.Role -in @(43,44) -and $_.Visible} | Group-Object BoundsKey | ForEach-Object {$_.Group[0]})
  if($matchesAccessible.Count -eq 1){return $matchesAccessible[0]}
  $labels=($accessible | Where-Object {$_.Role -in @(43,44)} | ForEach-Object {$_.Name}) -join ' / '
  Log "접근성 버튼 목록: $labels"
 }
 if($found.Count -ne 1){throw "컨트롤을 정확히 찾지 못했습니다: $name ($($found.Count)개). 작업을 중단합니다."}
 $found[0]
}
function InvokeControl($e){
 if($e.IsMsaa){$e.Click();return}
 $p=$null
 if(!$e.TryGetCurrentPattern([System.Windows.Automation.InvokePattern]::Pattern,[ref]$p)){throw '이 버튼은 접근성 클릭을 지원하지 않습니다. 화면 구조에 맞춘 추가 연결이 필요합니다.'}
 $p.Invoke()
}
function CheckControl($e){
 if($e.IsMsaa){
  if(($e.State -band 16) -eq 0){$e.Click()}
  if(($e.State -band 16) -eq 0){throw '체크 상태 확인 실패'}
  return
 }
 $p=$null
 if(!$e.TryGetCurrentPattern([System.Windows.Automation.TogglePattern]::Pattern,[ref]$p)){throw '체크박스 접근성을 확인할 수 없습니다.'}
 if($p.Current.ToggleState -eq [System.Windows.Automation.ToggleState]::Off){$p.Toggle()}
 if($p.Current.ToggleState -ne [System.Windows.Automation.ToggleState]::On){throw '체크 상태 확인 실패'}
}
function OpenPatrolSettings($dialog){
 $box=Named $dialog '3.댓글순방'
 if($box.IsMsaa){
  if(($box.State -band 16) -ne 0){
   Log '댓글 순방 체크를 해제합니다.';$box.Click()
   $dialog=WaitWindow '서이추 할 아이디 불러오기'
   $box=Named $dialog '3.댓글순방'
   if(($box.State -band 16) -ne 0){throw '댓글 순방 해제를 확인하지 못했습니다.'}
  }
  Log '댓글 순방을 다시 체크하여 계정 창을 엽니다.';$box.Click();return
 }
 $toggle=$null
 if(!$box.TryGetCurrentPattern([System.Windows.Automation.TogglePattern]::Pattern,[ref]$toggle)){throw '댓글 순방 체크 상태를 읽을 수 없습니다.'}
 if($toggle.Current.ToggleState -eq [System.Windows.Automation.ToggleState]::Indeterminate){throw '댓글 순방 체크 상태가 불명확합니다.'}
 if($toggle.Current.ToggleState -eq [System.Windows.Automation.ToggleState]::On){
  Log '댓글 순방이 체크되어 있어 먼저 해제합니다.'
  $toggle.Toggle()
  # The event may rebuild the VBA form controls; acquire them again.
  $dialog=WaitWindow '서이추 할 아이디 불러오기'
  $box=Named $dialog '3.댓글순방'
  $toggle=$null
  if(!$box.TryGetCurrentPattern([System.Windows.Automation.TogglePattern]::Pattern,[ref]$toggle)){throw '댓글 순방 체크박스를 다시 찾을 수 없습니다.'}
  if($toggle.Current.ToggleState -ne [System.Windows.Automation.ToggleState]::Off){throw '댓글 순방 체크 해제를 확인하지 못했습니다.'}
 }
 Log '댓글 순방을 새로 체크하여 계정 확인 창을 엽니다.'
 $toggle.Toggle()
}
function EditValue($e,$value){
 $p=$null
 if($e.TryGetCurrentPattern([System.Windows.Automation.ValuePattern]::Pattern,[ref]$p)){$p.SetValue($value);return}
 if($script:legacyType -and $e.TryGetCurrentPattern($script:legacyType::Pattern,[ref]$p)){$p.SetValue($value);return}
 throw '입력칸을 제어할 수 없습니다.'
}
function ReadValue($e){
 $p=$null
 if($e.TryGetCurrentPattern([System.Windows.Automation.ValuePattern]::Pattern,[ref]$p)){return $p.Current.Value}
 if($script:legacyType -and $e.TryGetCurrentPattern($script:legacyType::Pattern,[ref]$p)){return $p.Current.Value}
 throw '입력값을 읽을 수 없습니다.'
}
function InputFields($dialog){
 @(Nodes $dialog | Where-Object {
  $editable=$_.Current.ControlType -eq [System.Windows.Automation.ControlType]::Edit
  if(!$editable -and $script:legacyType){
   $legacy=$null
   if($_.TryGetCurrentPattern($script:legacyType::Pattern,[ref]$legacy)){$editable=$legacy.Current.Role -eq 42}
  }
  $editable
 } | Sort-Object {$_.Current.BoundingRectangle.Top})
}
function OpenExtract($window){
 $uiButtons=@(Nodes $window | Where-Object {$_.Current.Name.Replace(' ','') -eq '추출'})
 if($uiButtons.Count -eq 1){
  $pattern=$null
  if($uiButtons[0].TryGetCurrentPattern([System.Windows.Automation.InvokePattern]::Pattern,[ref]$pattern)){$pattern.Invoke();return}
 }
 # Excel sheet shapes are often absent from the UI Automation tree.
 $sheet=$script:book.Worksheets.Item('서이추')
 $sheet.Activate()
 $macros=New-Object 'System.Collections.Generic.List[string]'
 foreach($shape in $sheet.Shapes){
  $caption=''
  try{$caption=[string]$shape.TextFrame2.TextRange.Text}catch{}
  if(!$caption){try{$caption=[string]$shape.TextFrame.Characters().Text}catch{}}
  if(($caption -replace '\s','') -ne '추출'){continue}
  $action=[string]$shape.OnAction
  if(![string]::IsNullOrWhiteSpace($action)){$macros.Add($action)}
 }
 if($macros.Count -ne 1){throw "추출 도형의 연결 매크로를 정확히 찾지 못했습니다 ($($macros.Count)개)."}
 $procedure=$macros[0]
 if($procedure -notmatch '!'){$procedure="'"+$script:book.Name.Replace("'","''")+"'!"+$procedure}
 # Schedule instead of Run: Run blocks this program while a modal VBA form is open.
 $scheduled=(Get-Date).AddSeconds(1)
 $script:extractionSchedule=[pscustomobject]@{Time=$scheduled;Procedure=$procedure}
 $script:excel.OnTime($scheduled,$procedure,$scheduled.AddSeconds(15))
 Log '시트의 추출 도형에서 연결 매크로를 찾아 실행 예약했습니다.'
}
function PatrolSnapshot {
 $sheet=$script:book.Worksheets.Item('순방')
 $used=$sheet.UsedRange
 $lastRow=$used.Row+$used.Rows.Count-1
 $lastCol=$used.Column+$used.Columns.Count-1
 if($lastRow -gt 10000 -or $lastCol -gt 100){throw '순방 데이터 범위가 너무 큽니다. 자동 완료 판정을 중단합니다.'}
 $values=$sheet.Range($sheet.Cells.Item(1,1),$sheet.Cells.Item([Math]::Max(2,$lastRow),[Math]::Max(2,$lastCol))).Value2
 $headers=@{}
 $headerRow=0
 for($r=1;$r -le [Math]::Min(30,$lastRow);$r++){
  for($c=1;$c -le $lastCol;$c++){
   $text=([string]$values[$r,$c]).Trim()
   if($text -in @('닉네임','제목')){$headerRow=[Math]::Max($headerRow,$r)}
  }
 }
 if(!$headerRow){return @{Complete=$false;Fingerprint='';WorkKey='';Total=0;Done=0}}
 for($c=1;$c -le $lastCol;$c++){
  $header=([string]$values[$headerRow,$c]) -replace '\s',''
  if($header){$headers[$header]=$c}
 }
 $fingerprint=New-Object Text.StringBuilder
 for($r=1;$r -le $lastRow;$r++){for($c=1;$c -le $lastCol;$c++){[void]$fingerprint.Append(([string]$values[$r,$c])+'|')};[void]$fingerprint.AppendLine()}
 $hash=[Security.Cryptography.SHA256]::Create()
 try{$signature=[Convert]::ToBase64String($hash.ComputeHash([Text.Encoding]::UTF8.GetBytes($fingerprint.ToString())))}finally{$hash.Dispose()}
 foreach($required in @('닉네임','제목','좋아요','댓글','작업아이디','작업시간')){
  if(!$headers.ContainsKey($required)){return @{Complete=$false;Fingerprint=$signature;WorkKey='';Total=0;Done=0}}
 }
 $total=0;$done=0;$workRecords=New-Object Text.StringBuilder;$latestWorkTime=$null
 for($r=$headerRow+1;$r -le $lastRow;$r++){
  $hasNickname=![string]::IsNullOrWhiteSpace(([string]$values[$r,$headers['닉네임']]))
  $hasTitle=![string]::IsNullOrWhiteSpace(([string]$values[$r,$headers['제목']]))
  if(!$hasNickname -or !$hasTitle){continue}
  $total++
  $likeDone=([string]$values[$r,$headers['좋아요']]).Trim() -eq '완료'
  $commentDone=![string]::IsNullOrWhiteSpace(([string]$values[$r,$headers['댓글']]))
  $worker=([string]$values[$r,$headers['작업아이디']]).Trim()
  $timePresent=![string]::IsNullOrWhiteSpace(([string]$values[$r,$headers['작업시간']]))
  if($worker -ceq $script:expectedUsername -and $timePresent){
   $rawTime=$values[$r,$headers['작업시간']]
   [void]$workRecords.Append("$r="+([string]$rawTime)+";")
   $parsed=[datetime]::MinValue;$valid=$false
   if($rawTime -is [double]){try{$parsed=[datetime]::FromOADate($rawTime);$valid=$true}catch{}}
   else{$valid=[datetime]::TryParseExact(([string]$rawTime).Trim(),[string[]]@('MM-dd-yyyy H:mm','MM-dd-yyyy HH:mm','M-d-yyyy H:mm','yyyy-MM-dd H:mm','yyyy-MM-dd HH:mm:ss'),[Globalization.CultureInfo]::InvariantCulture,[Globalization.DateTimeStyles]::None,[ref]$parsed)}
   if($valid -and (!$latestWorkTime -or $parsed -gt $latestWorkTime)){$latestWorkTime=$parsed}
  }
  if($likeDone -and $commentDone -and $worker -ceq $script:expectedUsername -and $timePresent){$done++}
 }
 @{Complete=($total -gt 0 -and $done -eq $total);Fingerprint=$signature;WorkKey=$workRecords.ToString();LatestWorkTime=$latestWorkTime;Total=$total;Done=$done}
}
function ShouldCloseForIdle($hasNewWork,$seconds){return ($hasNewWork -and $seconds -gt 300)}
function ResetProgressClock {
 $script:seenNewWork=$false
 $script:idleWatch=New-Object Diagnostics.Stopwatch
 $script:idleOffset=0
}
function FinishOne {
 if(!$script:userConfirmedFinish){throw '사용자의 완료 확인이 없어 저장·닫기를 차단했습니다.'}
 $script:userConfirmedFinish=$false
 $timer.Stop()
 if(!$script:excel.Ready){throw '엑셀이 아직 작업 중입니다.'}
 $script:book.Save();$script:book.Close($false);$script:waiting=$false;$next.Enabled=$false
 Log "$($script:activeNumber) 번 저장·닫기 완료"
 if($script:activeNumber -lt $script:endNumber -and !$script:stopped){$number.Value=$script:activeNumber+1;StartOne}else{Log '선택한 작업 종료';$number.Enabled=$true;$endInput.Enabled=$true;$folderButton.Enabled=$true;$start.Enabled=$true;$sequence.Enabled=$true}
}
function StartOne {
 $n=[int]$number.Value
 ResetProgressClock
 $script:userConfirmedFinish=$false
 if(Test-Path -LiteralPath $finishRequest){Remove-Item -LiteralPath $finishRequest}
 $script:activeNumber=$n;$script:waiting=$false;$timer.Stop();$script:stableCount=0;$script:lastComplete='';$script:observedChange=$false
 $path=Join-Path $base "기관총 서이추 ($n).xlsb"
 if(!(Test-Path -LiteralPath $path)){throw "파일 없음: $path"}
 $accounts=LoadAccounts
 if(!$accounts.ContainsKey($n)){throw '먼저 계정 설정에서 번호별 아이디와 비밀번호를 저장하세요.'}
 $account=$accounts[$n]
 $script:expectedUsername=$account.Username
 $start.Enabled=$false;$sequence.Enabled=$false;$next.Enabled=$false;$number.Enabled=$false;$endInput.Enabled=$false;$folderButton.Enabled=$false;$script:stopped=$false
 Log "$n 번 파일 열기"
 try{$script:excel=[Runtime.InteropServices.Marshal]::GetActiveObject('Excel.Application')}catch{$script:excel=New-Object -ComObject Excel.Application}
 $existing=@($script:excel.Workbooks | Where-Object {$_.FullName -eq $path})
 if($existing.Count){$script:book=$existing[0]}else{$script:book=$script:excel.Workbooks.Open($path)}
 $script:excel.Visible=$true;$script:book.Activate()
 $process=Get-Process EXCEL | Where-Object {$_.MainWindowHandle -eq $script:excel.Hwnd} | Select-Object -First 1
 if(!$process){throw '대상 엑셀 프로세스를 식별하지 못했습니다.'}
 $script:pidExcel=$process.Id
 $deadline=(Get-Date).AddSeconds(90)
 Log '엑셀 준비 상태와 화면 표시를 기다립니다.'
 $readySince=$null
 do{
  if($script:stopped){throw '중지됨'}
  if((Get-Date)-gt $deadline){throw '엑셀 준비 시간 초과'}
  if($script:excel.Ready){if(!$readySince){$readySince=Get-Date}}else{$readySince=$null}
  if($readySince -and ((Get-Date)-$readySince).TotalSeconds -ge 3){break}
  [Windows.Forms.Application]::DoEvents();Start-Sleep -Milliseconds 300
 }while($true)
 Log '엑셀 준비 상태 3초 유지 확인. 추출을 엽니다.'
 $wins=@(ExcelWindows | Where-Object {$_.Current.Name -like "*기관총 서이추 ($n)*"})
 if($wins.Count -ne 1){throw '대상 엑셀 창을 정확히 식별하지 못했습니다.'}
 $dialog=$null
 for($attempt=1;$attempt -le 2;$attempt++){
  OpenExtract $wins[0]
  Log "추출 설정 창을 기다립니다 ($attempt/2)."
  try{$dialog=WaitWindow '서이추 할 아이디 불러오기';break}catch{
   if($script:extractionSchedule){
    try{$script:excel.OnTime($script:extractionSchedule.Time,$script:extractionSchedule.Procedure,[Type]::Missing,$false)}catch{}
    $script:extractionSchedule=$null
   }
   if($attempt -eq 2){throw}
   Log '추출 창이 열리지 않아 예약을 정리하고 한 번 재시도합니다.'
   $script:book.Activate()
  }
 }
 Log '추출 설정 창 확인. 키워드 입력칸을 찾습니다.'
 $edits=@(InputFields $dialog)
 if($edits.Count -ne 2){throw "검색 입력칸을 2개 예상했지만 $($edits.Count)개 찾았습니다. 키워드 입력 단계에서 중단했습니다."}
 $keyword=Get-Random -InputObject $keywords
 EditValue $edits[0] $keyword
 if((ReadValue $edits[0]) -cne $keyword){throw '새 키워드 입력 후 일치 확인에 실패했습니다.'}
 Log "검색 키워드: $keyword / 불러올 개수와 정렬은 기존 값 유지"
 CheckControl (Named $dialog '1.키워드추출')
 CheckControl (Named $dialog '2.서이추')
 OpenPatrolSettings $dialog
 $visit=WaitWindow '순방'
 $accountEdits=@(Nodes $visit | Where-Object {$_.Current.ControlType -eq [System.Windows.Automation.ControlType]::Edit -and $_.Current.BoundingRectangle.Height -gt 50})
 if($accountEdits.Count -ne 1){throw '계정 입력칸을 정확히 찾지 못했습니다.'}
 $v=ReadValue $accountEdits[0]
 $credential=New-Object Management.Automation.PSCredential($account.Username,$account.Password)
 $expected='{'+$n+'}'+$account.Username+','+$credential.GetNetworkCredential().Password
 try{
  if($v.Trim() -cne $expected){
   EditValue $accountEdits[0] $expected
   $actual=ReadValue $accountEdits[0]
   if($actual.Trim() -cne $expected){throw '계정 정보 수정 후 일치 확인에 실패했습니다.'}
   Log "$n 번 계정 정보를 설정값으로 수정했습니다."
  }else{Log "$n 번 계정 번호·아이디·비밀번호 일치 확인 완료"}
 }finally{$expected=$null;$actual=$null;$v=$null;$credential=$null}
 InvokeControl (Named $visit '저장')
 $dialog=WaitWindow '서이추 할 아이디 불러오기'
 foreach($label in @('1.키워드추출','2.서이추','3.댓글순방')){CheckControl (Named $dialog $label)}
 $script:lastWorkKey=(PatrolSnapshot).WorkKey
 InvokeControl (Named $dialog '세트시작')
 $script:waiting=$true;$next.Enabled=$true
 $timer.Start()
 Log '세트 시작 요청 완료. 이번 실행의 작업시간 기록이 갱신된 후 5분 초과 정지하면 저장·닫기 합니다.'
}
$form=New-Object Windows.Forms.Form
$form.Text='기관총 액셀 서이추 · 번호 범위 / 작업시간 5분 감시';$form.Size=New-Object Drawing.Size(740,610);$form.StartPosition='CenterScreen'
$label=New-Object Windows.Forms.Label;$label.Text='시작 번호';$label.SetBounds(20,23,65,22);$form.Controls.Add($label)
$number=New-Object Windows.Forms.NumericUpDown;$number.Minimum=1;$number.Maximum=10;$number.Location=New-Object Drawing.Point(85,20);$number.Width=55;$form.Controls.Add($number)
$endLabel=New-Object Windows.Forms.Label;$endLabel.Text='끝 번호';$endLabel.SetBounds(155,23,55,22);$form.Controls.Add($endLabel)
$endInput=New-Object Windows.Forms.NumericUpDown;$endInput.Minimum=1;$endInput.Maximum=10;$endInput.Value=10;$endInput.SetBounds(210,20,55,25);$form.Controls.Add($endInput)
$start=New-Object Windows.Forms.Button;$start.Text='시작 번호만 실행';$start.SetBounds(285,17,145,32);$form.Controls.Add($start)
$sequence=New-Object Windows.Forms.Button;$sequence.Text='입력 범위 연속 실행';$sequence.SetBounds(440,17,150,32);$form.Controls.Add($sequence)
$next=New-Object Windows.Forms.Button;$next.Text='수동 완료 확인';$next.SetBounds(20,62,165,32);$next.Enabled=$false;$form.Controls.Add($next)
$accountButton=New-Object Windows.Forms.Button;$accountButton.Text='계정 설정 (1~10번)';$accountButton.SetBounds(205,62,200,32);$form.Controls.Add($accountButton)
$accountButton.Add_Click({if($script:waiting -or !$start.Enabled){[void][Windows.Forms.MessageBox]::Show('작업이 끝난 후 계정을 변경하세요.');return};try{AccountSettings}catch{Log $_.Exception.Message}})
$idleLabel=New-Object Windows.Forms.Label;$idleLabel.Text='순방 작업시간 갱신 대기';$idleLabel.SetBounds(425,70,275,22);$form.Controls.Add($idleLabel)
$resume=New-Object Windows.Forms.Button;$resume.Text='열린 파일 감시만 재개 (세트 재실행 없음)';$resume.SetBounds(20,97,350,28);$form.Controls.Add($resume)
$resumeSequence=New-Object Windows.Forms.CheckBox;$resumeSequence.Text='감시 재개 후 입력한 끝 번호까지';$resumeSequence.SetBounds(390,100,300,24);$form.Controls.Add($resumeSequence)
$resume.Add_Click({
 if($script:waiting){return}
 try{
  $n=[int]$number.Value;$accounts=LoadAccounts
  if($resumeSequence.Checked){CheckRange $n ([int]$endInput.Value)}
  if(!$accounts.ContainsKey($n)){throw '계정 설정이 없습니다.'}
  $script:excel=[Runtime.InteropServices.Marshal]::GetActiveObject('Excel.Application')
  $path=Join-Path $base "기관총 서이추 ($n).xlsb"
  $books=@($script:excel.Workbooks | Where-Object {$_.FullName -eq $path})
  if($books.Count -eq 0){
   $openTarget=@(Get-Process EXCEL | Where-Object {$_.MainWindowTitle -like "*기관총 서이추 ($n)*"})
   if($openTarget.Count -eq 1){
    $attached=[Runtime.InteropServices.Marshal]::BindToMoniker($path)
    $script:excel=$attached.Application;$books=@($attached)
   }
  }
  if($books.Count -ne 1){throw '선택한 번호의 파일이 Excel에 열려 있어야 합니다.'}
  $script:book=$books[0];$script:expectedUsername=$accounts[$n].Username
  $process=Get-Process EXCEL | Where-Object {$_.MainWindowHandle -eq $script:excel.Hwnd} | Select-Object -First 1
  if(!$process){throw '엑셀 프로세스를 찾지 못했습니다.'}
  $script:pidExcel=$process.Id;$script:activeNumber=$n
  if($resumeSequence.Checked){$script:endNumber=[int]$endInput.Value}else{$script:endNumber=$n}
  ResetProgressClock
  $resumeSnapshot=PatrolSnapshot;$script:lastWorkKey=$resumeSnapshot.WorkKey
  if(!$script:lastWorkKey){throw '선택한 계정의 작업시간 기록을 읽지 못했습니다.'}
  $script:seenNewWork=$true;$script:idleWatch.Start();$script:stopped=$false;$script:waiting=$true
  if($resumeSnapshot.LatestWorkTime){
   $koreaNow=[TimeZoneInfo]::ConvertTimeBySystemTimeZoneId([datetime]::UtcNow,'Korea Standard Time')
   $script:idleOffset=[Math]::Max(0,($koreaNow-$resumeSnapshot.LatestWorkTime).TotalSeconds)
  }
  $start.Enabled=$false;$sequence.Enabled=$false;$number.Enabled=$false;$endInput.Enabled=$false;$folderButton.Enabled=$false;$next.Enabled=$true
  Log "$n 번 감시 재개. 마지막 작업시간 이후 $([int]$script:idleOffset)초 경과. 세트는 다시 실행하지 않습니다."
  $timer.Start()
 }catch{ReportFailure $_}
})
$stop=New-Object Windows.Forms.Button;$stop.Text='루틴 중지';$stop.SetBounds(600,17,100,32);$form.Controls.Add($stop)
$info=New-Object Windows.Forms.Label;$info.Text="시작·끝 번호를 직접 입력하세요. 예: 이 컴퓨터 1~5 / 다른 컴퓨터 6~10.`r`n중지는 다음 작업만 막으며, 이미 실행한 엑셀 매크로는 중지하지 않습니다.";$info.SetBounds(20,130,680,45);$form.Controls.Add($info)
$log=New-Object Windows.Forms.TextBox;$log.Multiline=$true;$log.ReadOnly=$true;$log.ScrollBars='Vertical';$log.SetBounds(20,185,680,265);$form.Controls.Add($log)
$folderLabel=New-Object Windows.Forms.Label;$folderLabel.Text='엑셀 폴더: '+$base;$folderLabel.SetBounds(20,465,525,48);$form.Controls.Add($folderLabel)
$folderButton=New-Object Windows.Forms.Button;$folderButton.Text='엑셀 폴더 선택';$folderButton.SetBounds(550,465,150,32);$form.Controls.Add($folderButton)
$folderButton.Add_Click({
 if($script:waiting -or !$start.Enabled){return}
 $picker=New-Object Windows.Forms.FolderBrowserDialog;$picker.Description='기관총 서이추 (번호).xlsb 파일이 있는 폴더';$picker.SelectedPath=$base
 if($picker.ShowDialog($form) -eq 'OK'){
  $script:base=$picker.SelectedPath
  @{ExcelFolder=$script:base} | ConvertTo-Json | Set-Content -LiteralPath $settingsFile -Encoding UTF8
  $folderLabel.Text='엑셀 폴더: '+$script:base
 }
 $picker.Dispose()
})
$updateButton=New-Object Windows.Forms.Button;$updateButton.Text='업데이트 확인';$updateButton.SetBounds(550,515,150,32);$form.Controls.Add($updateButton);$updateButton.Add_Click({CheckProgramUpdate})
$portableNote=New-Object Windows.Forms.Label;$portableNote.Text='다른 컴퓨터에서는 계정 설정을 다시 등록하세요. 서로 다른 번호 범위를 지정하면 각각 실행합니다.';$portableNote.SetBounds(20,520,520,40);$form.Controls.Add($portableNote)
$timer=New-Object Windows.Forms.Timer;$timer.Interval=5000
$timer.Add_Tick({
 if(!$script:waiting -or $script:stopped){return}
 $timer.Stop()
 try{
  if(Test-Path -LiteralPath $finishRequest){
   $requestedNumber=0
   $requestedText=[IO.File]::ReadAllText($finishRequest).Trim()
   if([int]::TryParse($requestedText,[ref]$requestedNumber) -and $requestedNumber -eq $script:activeNumber){
    if($script:excel.Ready){
     Log '사용자의 완료 확인 요청 수신. 현재 파일을 저장하고 닫습니다.'
     Remove-Item -LiteralPath $finishRequest
     $script:userConfirmedFinish=$true
     FinishOne;return
    }
   }
  }
  $snapshot=PatrolSnapshot
  if($snapshot.WorkKey -cne $script:lastWorkKey){
   $script:lastWorkKey=$snapshot.WorkKey
   if($snapshot.WorkKey){
    $script:seenNewWork=$true;$script:idleOffset=0;$script:idleWatch.Restart()
    Log '순방 작업시간 갱신 확인. 5분 타이머를 다시 시작합니다.'
   }else{$script:seenNewWork=$false;$script:idleWatch.Reset()}
  }
  $idleSeconds=$script:idleOffset+$script:idleWatch.Elapsed.TotalSeconds
  if($script:seenNewWork){$idleLabel.Text='순방 작업시간 갱신 후 '+[int]$idleSeconds+'초'}else{$idleLabel.Text='순방의 새 작업시간 기록 대기'}
  $busy=@([RoutineWindowFinder]::List($script:pidExcel) | Where-Object {$_.ClassName -match 'Thunder|#32770'})
  if((ShouldCloseForIdle $script:seenNewWork $idleSeconds) -and $busy.Count -eq 0 -and $script:excel.Ready){
   Log '순방 작업시간이 5분 넘게 갱신되지 않아 사용자 지정 규칙으로 저장·닫기 합니다.'
   $script:userConfirmedFinish=$true;FinishOne;return
  }
 }catch{
  $script:stableCount=0
  $idleLabel.Text='조회 오류 — 5초 후 자동 재시도'
  if(!$script:lastReadErrorLog -or ((Get-Date)-$script:lastReadErrorLog).TotalSeconds -ge 60){
   Log ('감시 조회 오류. 감시를 종료하지 않고 재시도합니다: '+$_.Exception.Message)
   $script:lastReadErrorLog=Get-Date
  }
 }
 if($script:waiting -and !$script:stopped){$timer.Start()}
})
$start.Add_Click({$script:endNumber=[int]$number.Value;Log "$($number.Value) 번만 실행";try{StartOne}catch{ReportFailure $_;$start.Enabled=$true;$sequence.Enabled=$true;$number.Enabled=$true;$endInput.Enabled=$true;$folderButton.Enabled=$true}})
$sequence.Add_Click({try{CheckRange ([int]$number.Value) ([int]$endInput.Value);$script:endNumber=[int]$endInput.Value;Log "$($number.Value) 번부터 $($endInput.Value) 번까지 실행";StartOne}catch{ReportFailure $_;$start.Enabled=$true;$sequence.Enabled=$true;$number.Enabled=$true;$endInput.Enabled=$true;$folderButton.Enabled=$true}})
$next.Add_Click({
 if(!$script:waiting){return}
 if([Windows.Forms.MessageBox]::Show('키워드 추출·서이추·댓글 순방까지 모두 끝났나요? 현재 파일을 저장하고 닫습니다.','전체 완료 확인','YesNo') -ne 'Yes'){return}
 try{
  $script:userConfirmedFinish=$true
  FinishOne
 }catch{Log $_.Exception.Message}
})
$stop.Add_Click({$script:stopped=$true;$timer.Stop();$next.Enabled=$false;Log '다음 작업 중지. 실행 중인 엑셀 매크로는 엑셀에서 직접 종료해야 합니다. 재시작하려면 프로그램을 다시 여세요.'})
$form.Add_FormClosing({if($script:waiting){if([Windows.Forms.MessageBox]::Show('엑셀 작업은 계속 실행됩니다. 이 프로그램만 닫을까요?','종료','YesNo') -ne 'Yes'){$_.Cancel=$true}}})
if($SelfTest){ResetProgressClock;$script:idleWatch.Restart();if($script:idleWatch -eq $null -or !$script:idleWatch.IsRunning){throw '타이머 초기화 검사 실패'};$script:idleWatch.Reset();'STARTUP_AND_TIMER_OK';$form.Dispose();exit 0}
Log '작업시간 5분 감시 버전 시작 — 새 작업시간 기록 이후 5분 초과 무변경 시 저장·닫기'
if($ResumeNumber -gt 0){
 $form.Add_Shown({$number.Value=$ResumeNumber;$resumeSequence.Checked=[bool]$ResumeToEnd;$resume.PerformClick()})
}
[void]$form.ShowDialog()
