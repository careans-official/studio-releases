﻿$script:AppVersion='1.1.0'
$script:ReleaseRepo='careans-official/studio-releases'
function CheckProgramUpdate {
 if($script:waiting -or !$start.Enabled -or (ParallelWorkersRunning)){Log '현재 작업이 끝난 뒤 업데이트하세요.';return}
 $updateButton.Enabled=$false
 try{
  [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12
  $headers=@{'User-Agent'='GatlingExcel/'+$script:AppVersion;Accept='application/vnd.github+json'}
  $releases=Invoke-RestMethod -Uri ('https://api.github.com/repos/'+$script:ReleaseRepo+'/releases?per_page=100') -Headers $headers -TimeoutSec 25
  $candidates=@($releases | Where-Object {!$_.draft -and !$_.prerelease -and $_.tag_name -match '^gatling-excel-v\d+\.\d+\.\d+$'} | Sort-Object {[version]($_.tag_name -replace '^gatling-excel-v','')} -Descending)
  if(!$candidates.Count){Log '기관총 전용 업데이트가 아직 배포되지 않았습니다.';return}
  $release=$candidates[0];$latest=$release.tag_name -replace '^gatling-excel-v',''
  if([version]$latest -le [version]$script:AppVersion){Log ('최신 버전입니다: '+$script:AppVersion);return}
  $manifestAsset=@($release.assets | Where-Object {$_.name -eq 'gatling-excel-update.json'})
  if($manifestAsset.Count -ne 1){throw '기관총 업데이트 정보 파일이 없습니다.'}
  $prefix='https://github.com/'+$script:ReleaseRepo+'/releases/download/'+$release.tag_name+'/'
  if(!$manifestAsset[0].browser_download_url.StartsWith($prefix,[StringComparison]::Ordinal)){throw '업데이트 정보 주소 불일치'}
  $manifest=Invoke-RestMethod -Uri $manifestAsset[0].browser_download_url -Headers $headers -TimeoutSec 25
  if($manifest.product -ne 'gatling-excel' -or $manifest.version -ne $latest -or $manifest.sha256 -notmatch '^[a-fA-F0-9]{64}$' -or !$manifest.url.StartsWith($prefix,[StringComparison]::Ordinal)){throw '기관총 업데이트 검증 정보가 올바르지 않습니다.'}
  if([Windows.Forms.MessageBox]::Show("버전 $latest 로 프로그램만 업데이트할까요? 계정·폴더·프록시 설정은 유지됩니다.",'기관총 액셀 서이추 업데이트','YesNo') -ne 'Yes'){return}
  $stage=Join-Path ([IO.Path]::GetTempPath()) ('gatling-update-'+[guid]::NewGuid().ToString('N'))
  New-Item -ItemType Directory -Path $stage | Out-Null
  $archive=Join-Path $stage 'package.zip'
  Invoke-WebRequest -Uri $manifest.url -Headers $headers -OutFile $archive -UseBasicParsing -TimeoutSec 120
  if((Get-FileHash -LiteralPath $archive -Algorithm SHA256).Hash -ine $manifest.sha256){throw '다운로드 파일 검증 실패. 설치하지 않습니다.'}
  Add-Type -AssemblyName System.IO.Compression.FileSystem
  $allowed=@('기관총 액셀 서이추.exe','routine.ps1','app-update.ps1','version.json','실행.cmd','사용법.txt')
  $zip=[IO.Compression.ZipFile]::OpenRead($archive)
  try{
   $names=@($zip.Entries | ForEach-Object {$_.FullName})
   if($names.Count -ne $allowed.Count -or @($names | Sort-Object -Unique).Count -ne $names.Count){throw '업데이트 파일 개수 불일치'}
   foreach($entry in $zip.Entries){if($entry.FullName -cnotin $allowed -or $entry.Length -gt 20000000){throw '허용되지 않은 업데이트 파일'}}
  }finally{$zip.Dispose()}
  $payload=Join-Path $stage 'files';[IO.Compression.ZipFile]::ExtractToDirectory($archive,$payload)
  $plan=@{Target=$PSScriptRoot;Source=$payload;Files=$allowed;ProcessId=$PID;LauncherId=0}
  $parent=(Get-CimInstance Win32_Process -Filter "ProcessId=$PID").ParentProcessId
  $parentProcess=Get-CimInstance Win32_Process -Filter "ProcessId=$parent"
  if($parentProcess.ExecutablePath -eq (Join-Path $PSScriptRoot '기관총 액셀 서이추.exe')){$plan.LauncherId=$parent}
  $plan | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $stage 'plan.json') -Encoding UTF8
  $helper=@'
$ErrorActionPreference='Stop'
try{
 $plan=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'plan.json') -Raw | ConvertFrom-Json
 Wait-Process -Id $plan.ProcessId -ErrorAction SilentlyContinue
 if($plan.LauncherId){Wait-Process -Id $plan.LauncherId -ErrorAction SilentlyContinue}
 $backup=Join-Path $plan.Target ('update-backup-'+(Get-Date -Format 'yyyyMMdd-HHmmss'))
 New-Item -ItemType Directory -Path $backup | Out-Null
 foreach($name in $plan.Files){$old=Join-Path $plan.Target $name;if(Test-Path -LiteralPath $old){Copy-Item -LiteralPath $old -Destination (Join-Path $backup $name)}}
 try{foreach($name in $plan.Files){Copy-Item -LiteralPath (Join-Path $plan.Source $name) -Destination (Join-Path $plan.Target $name) -Force}}catch{
  foreach($file in (Get-ChildItem -LiteralPath $backup -File)){Copy-Item -LiteralPath $file.FullName -Destination (Join-Path $plan.Target $file.Name) -Force};throw
 }
 Start-Process -FilePath (Join-Path $plan.Target '기관총 액셀 서이추.exe')
}catch{
 Add-Type -AssemblyName System.Windows.Forms
 [void][Windows.Forms.MessageBox]::Show($_.Exception.Message,'기관총 업데이트 실패')
}
'@
  $helperFile=Join-Path $stage 'apply.ps1';[IO.File]::WriteAllText($helperFile,$helper,(New-Object Text.UTF8Encoding($true)))
  $argsText='-NoProfile -ExecutionPolicy Bypass -File "'+$helperFile+'"'
  Start-Process -FilePath (Join-Path $env:WINDIR 'System32\WindowsPowerShell\v1.0\powershell.exe') -ArgumentList $argsText -WindowStyle Hidden
  $form.Close()
 }catch{Log ('업데이트 실패: '+$_.Exception.Message)}finally{$updateButton.Enabled=$true}
}
